package com.hexa.assetmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
